compile with the following command:
g++ Project1.cpp -o project1